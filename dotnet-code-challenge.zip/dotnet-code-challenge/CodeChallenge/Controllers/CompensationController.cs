﻿using CodeChallenge.Services;
using CodeChallenge.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

namespace CodeChallenge.Controllers
{
    [ApiController]
    [Route("api/compensation")]
    public class CompensationController : ControllerBase
    {
        private readonly ILogger _logger;
        private readonly ICompensationService _compensationService;

        public CompensationController(ILogger<CompensationController> logger, ICompensationService compensationService)
        {
            _logger = logger;
            _compensationService = compensationService;
        }

        [HttpPost]
        public IActionResult CreateCompensation([FromBody]CompensationCreator compensation)
        {
            try
            {
                var createdCompensation = _compensationService.CreateCompensation(compensation);
                if (createdCompensation == null)
                {
                    return BadRequest("An error has occurred while creating compensation.");
                }
                return CreatedAtRoute("getCompensationById", new { id = createdCompensation.CompensationId }, createdCompensation);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("{id}", Name = "getCompensationById")]
        public IActionResult GetCompensation(string id)
        {
            var compensation = _compensationService.GetCompensation(id);
            if(compensation == null)
            { 
                return NotFound(); 
            }

            return Ok(compensation);
        }
    }
}
