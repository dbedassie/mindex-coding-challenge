﻿using CodeChallenge.Data;
using CodeChallenge.Models;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CodeChallenge.Repositories
{
    public interface ICompensationRepository
    {
        Compensation Create(Compensation compensation);
        Compensation GetCompensationById(string id);
        Task SaveAsync();
        public IEnumerable<Compensation> GetAll();
        void Delete(Compensation compensation);
    }
}
