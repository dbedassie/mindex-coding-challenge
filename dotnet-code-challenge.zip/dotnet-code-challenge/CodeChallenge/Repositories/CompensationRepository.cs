﻿using CodeChallenge.Data;
using CodeChallenge.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CodeChallenge.Repositories
{
    public class CompensationRepository : ICompensationRepository
    {
        private readonly EmployeeContext _employeeContext;
        private readonly ILogger<ICompensationRepository> _logger;

        public CompensationRepository(ILogger<ICompensationRepository> logger, EmployeeContext employeeContext)
        {
            _employeeContext = employeeContext;
            _logger = logger;
        }

        public Compensation Create(Compensation compensation)
        {
            _employeeContext.Compensations.Add(compensation);
            return compensation;
        }

        public Compensation GetCompensationById(string id)
        {
            return _employeeContext.Compensations.Include(c => c.Employee).ThenInclude(e => e.DirectReports).FirstOrDefault(c => c.Employee.EmployeeId == id);
        }

        public void Delete(Compensation compensation)
        {
            _employeeContext.Compensations.Remove(compensation);
        }

        public Task SaveAsync()
        {
            return _employeeContext.SaveChangesAsync();
        }

        public IEnumerable<Compensation> GetAll()
        {
            return _employeeContext.Compensations.ToList();
        }
    }
}
