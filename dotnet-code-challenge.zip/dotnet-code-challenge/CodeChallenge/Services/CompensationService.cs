﻿using CodeChallenge.Models;
using CodeChallenge.Repositories;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;

namespace CodeChallenge.Services
{
    public class CompensationService : ICompensationService
    {
        private readonly ICompensationRepository _compensationRepository;
        private readonly IEmployeeRepository _employeeRepository;
        private readonly ILogger<CompensationService> _logger;

        public CompensationService(ILogger<CompensationService> logger, ICompensationRepository compensationRepository, IEmployeeRepository employeeRepository)
        {
            _logger = logger;
            _compensationRepository = compensationRepository;
            _employeeRepository = employeeRepository;
        }

        public Compensation CreateCompensation(CompensationCreator compensation)
        {
            #region Validation
            // Salary must be a positive integer.
            if (compensation.Salary <= 0)
            {
                throw new ArgumentException("Salary must be a positive integer.");
            }

            /* -- Commented out because this validation was not specified.
            if(compensation.EffectiveDate.Date < DateTime.Today)
            {
                throw new ArgumentException("EffectiveDate must not be eariler than today.");
            }
            */

            // Employee must exist so we can apply a compensation.
            var employee = _employeeRepository.GetById(compensation.EmployeeId);
            if(employee == null)
            {
                throw new KeyNotFoundException("Employee not found.");
            }
            #endregion

            #region Existing Compensation
            // IF THE EMPLOYEE ALREADY HAS AN EXISTING COMPENSATION
            // I have decided to DELETE the former compensation and replace with the new compensation.
            // instead of UPDATING the compensation.
            var existingCompensation = _compensationRepository
                .GetAll()
                .FirstOrDefault(c => c.Employee != null && c.Employee.EmployeeId == compensation.EmployeeId);

            if(existingCompensation != null)
            {
                _compensationRepository.Delete(existingCompensation);
            }
            #endregion

            #region DTO morphing
            // DTO -> Compensation object
            var newCompensation = new Compensation
            {
                CompensationId = Guid.NewGuid().ToString(),
                Employee = employee,
                Salary = compensation.Salary,
                EffectiveDate = compensation.EffectiveDate
            };
            #endregion

            newCompensation = _compensationRepository.Create(newCompensation);
            _compensationRepository.SaveAsync().Wait();
            return newCompensation;
        }

        public Compensation GetCompensation(string id)
        {
            return _compensationRepository.GetCompensationById(id);
        }
    }
}
