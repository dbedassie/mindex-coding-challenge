﻿using CodeChallenge.Models;

namespace CodeChallenge.Services
{
    public interface ICompensationService
    {
        Compensation CreateCompensation(CompensationCreator compensation);
        Compensation GetCompensation(string id);
    }
}
