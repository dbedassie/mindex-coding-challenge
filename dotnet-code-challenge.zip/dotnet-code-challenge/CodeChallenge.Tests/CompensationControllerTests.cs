﻿using System;
using System.Net;
using System.Net.Http;
using System.Text;
using CodeChallenge.Models;
using CodeCodeChallenge.Tests.Integration.Extensions;
using CodeCodeChallenge.Tests.Integration.Helpers;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CodeChallenge.Tests.Integration
{
    [TestClass]
    public class CompensationControllerTests
    {
        private static HttpClient _httpClient;
        private static TestServer _testServer;

        [ClassInitialize]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Style", "IDE0060:Remove unused parameter", Justification = "<Pending>")]
        public static void InitializeClass(TestContext context)
        {
            _testServer = new TestServer();
            _httpClient = _testServer.NewClient();
        }

        [ClassCleanup]
        public static void CleanUpTest()
        {
            _httpClient.Dispose();
            _testServer.Dispose();
        }

        /// <summary>
        /// Initalizing a Compensation in our DB so our GetCompensation test does not fail.
        /// </summary>
        [TestInitialize]
        public void TestSetup()
        {
            var compensationCreator = new CompensationCreator()
            {
                Salary = 100000,
                EffectiveDate = DateTime.Today,
                EmployeeId = "16a596ae-edd3-4847-99fe-c4518e82c86f"
            };

            var requestContent = new JsonSerialization().ToJson(compensationCreator);

            var postRequestTask = _httpClient.PostAsync("api/compensation", new StringContent(requestContent, Encoding.UTF8, "application/json"));
            var response = postRequestTask.Result;

            Assert.AreEqual(HttpStatusCode.Created, response.StatusCode);
        }

        [TestMethod]
        public void CreateCompensation_Returns_Created()
        {
            var compensationCreator = new CompensationCreator()
            {
                Salary = 100000,
                EffectiveDate = DateTime.Today,
                EmployeeId = "16a596ae-edd3-4847-99fe-c4518e82c86f"
            };

            var requestContent = new JsonSerialization().ToJson(compensationCreator);

            var postRequestTask = _httpClient.PostAsync("api/compensation", new StringContent(requestContent, Encoding.UTF8, "application/json"));
            var response = postRequestTask.Result;

            Assert.AreEqual(HttpStatusCode.Created, response.StatusCode);

            var compensation = response.DeserializeContent<Compensation>();
            Assert.IsNotNull(compensation.Employee);
            Assert.AreEqual(compensationCreator.EmployeeId, compensation.Employee.EmployeeId);
            Assert.AreEqual(compensationCreator.Salary, compensation.Salary);
            Assert.AreEqual(compensation.EffectiveDate, DateTime.Today);
        }

        [TestMethod]
        [DataRow(-2, "16a596ae-edd3-4847-99fe-c4518e82c86f", "Salary must be a positive integer.")]
        [DataRow(100000, "123", "Employee not found.")]
        public void CreateCompensation_Returns_BadRequest(int salary, string employeeId, string errorMessage)
        {
            var compensationCreator = new CompensationCreator()
            {
                Salary = salary,
                EffectiveDate = DateTime.Today,
                EmployeeId = employeeId
            };

            var requestContent = new JsonSerialization().ToJson(compensationCreator);

            var postRequestTask = _httpClient.PostAsync("api/compensation", new StringContent(requestContent, Encoding.UTF8, "application/json"));
            var response = postRequestTask.Result;
            var responseContent = response.Content.ReadAsStringAsync().Result;

            Assert.AreEqual(HttpStatusCode.BadRequest, response.StatusCode);
            Assert.IsTrue(responseContent.Contains(errorMessage));
        }

        [TestMethod]
        public void GetCompensation_Returns_NotFound()
        {
            string employeeId = "123";

            var getRequestTask = _httpClient.GetAsync($"api/compensation/{employeeId}");
            var response = getRequestTask.Result;

            Assert.AreEqual(HttpStatusCode.NotFound, response.StatusCode);
        }

        /// <summary>
        /// This test can only be ran AFTER CreateCompensation_Returns_Created() because we are NOT seeding any data into our db, therefore, no Compensations exist in our DB yet.
        /// </summary>
        [TestMethod]
        public void GetCompensation_Returns_Ok_AfterCreate()
        {
            string employeeId = "16a596ae-edd3-4847-99fe-c4518e82c86f";
            int salary = 100000;
            DateTime effectiveDate = DateTime.Today;

            var getRequestTask = _httpClient.GetAsync($"api/compensation/{employeeId}");
            var response = getRequestTask.Result;

            var compensation = response.DeserializeContent<Compensation>();
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
            Assert.AreEqual(compensation.Salary, salary);
            Assert.AreEqual(compensation.Employee.EmployeeId, employeeId);
            Assert.AreEqual(compensation.EffectiveDate, effectiveDate);
        }
    }
}
