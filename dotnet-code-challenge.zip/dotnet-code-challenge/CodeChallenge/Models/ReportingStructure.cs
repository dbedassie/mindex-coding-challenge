﻿namespace CodeChallenge.Models
{
    public class ReportingStructure
    {
        public int NumberOfReports => CalculateNumberOfReports(Employee);
        public Employee Employee { get; set; }

        // Calculating number of reports on the fly -- recursively so we can track the reports of DirectReports
        private int CalculateNumberOfReports(Employee employee)
        {
            // If no direct reports, then NumberOfReports = 0
            if(employee.DirectReports == null || employee?.DirectReports.Count == 0)
            {
                return 0;
            }

            // Foreach report that this employee has, check their reports recursively and add to our total NumberOfReports
            int reports = 0;
            foreach(var report in employee.DirectReports)
            {
                reports += 1 + CalculateNumberOfReports(report);
            }

            return reports;
        }
    }
}
