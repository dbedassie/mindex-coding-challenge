﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace CodeChallenge.Models
{
    public class Compensation
    {
        [JsonIgnore] // This wasn't specified as a need, our Compensation will be searched by EmployeeId, this will just be a primary key for our in-mem db. Can be removed.
        public string CompensationId { get; set; }
        public int Salary { get; set; }
        public DateTime EffectiveDate { get; set; }
        public Employee Employee { get; set; }
    }

    /// <summary>
    /// Using this struct as a DTO for the Compensation class.
    /// </summary>
    public struct CompensationCreator
    {
        public string EmployeeId { get; set; }
        public int Salary { get; set; }
        public DateTime EffectiveDate { get; set;}
    }
}
